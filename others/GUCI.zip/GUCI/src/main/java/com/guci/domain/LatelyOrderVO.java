package com.guci.domain;

import java.util.Date;

import lombok.Data;

@Data
public class LatelyOrderVO {
	private String gdsName, userId;
	private Long stock, price;
	private Date orderDate;
}
