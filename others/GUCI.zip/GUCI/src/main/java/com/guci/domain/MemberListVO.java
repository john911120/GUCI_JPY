package com.guci.domain;

import java.util.Date;

import lombok.Data;

@Data
public class MemberListVO {
	private String userId, userName;
	private int orderNum, orderPrice;
	private Date regDate;
	private Long stock, sum;
}
