package com.guci.domain;

import lombok.Data;

@Data
public class OrderInfoVO {
	private String userId, orderRec, orderAddr1, orderAddr2, orderAddr3, orderPhone;
}
