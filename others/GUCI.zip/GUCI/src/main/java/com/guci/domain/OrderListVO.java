package com.guci.domain;

public class OrderListVO {
	public String name;
}
