package com.guci.domain;

import lombok.Data;

@Data
public class TestVO {
	private int cartNo;
	private String userId;
}
