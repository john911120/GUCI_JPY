package com.guci.mapper;

import java.util.List;

import com.guci.domain.LatelyOrderVO;
import com.guci.domain.OrderListVO;

public interface AdminMapper {
	public int totalIncome();
	public String todayIncome();
	public String todaySalesQuantity();
	public int questionNo();

	public List<OrderListVO> memberList();

	public List<LatelyOrderVO> latelyOrderList();
}
