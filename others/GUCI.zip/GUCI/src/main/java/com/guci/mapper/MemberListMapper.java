package com.guci.mapper;

import java.util.List;

import com.guci.domain.MemberListVO;

public interface MemberListMapper {
	public List<MemberListVO> getList();
}
