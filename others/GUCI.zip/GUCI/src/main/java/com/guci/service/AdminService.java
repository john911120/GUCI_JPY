package com.guci.service;

import java.util.List;

import com.guci.domain.LatelyOrderVO;

public interface AdminService {
	public int questionNo();
	public int totalIncome();
	public String todayIncome();
	public String todaySalesQuantity();

	public List<LatelyOrderVO> latelyOrderList();
}
