package com.guci.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.guci.domain.LatelyOrderVO;
import com.guci.mapper.AdminMapper;

@Service
public class AdminServiceImpl implements AdminService{

	//@Setter(onMethod_=@Autowired)
	@Autowired
	private AdminMapper mapper;

	@Override
	public int questionNo() {
		return mapper.questionNo();
	}

	@Override
	public List<LatelyOrderVO> latelyOrderList() {
		return mapper.latelyOrderList();
	}

	@Override
	public int totalIncome() {
		return mapper.totalIncome();
	}

	@Override
	public String todayIncome() {
		return mapper.todayIncome();
	}

	@Override
	public String todaySalesQuantity() {
		return mapper.todaySalesQuantity();
	}

}
