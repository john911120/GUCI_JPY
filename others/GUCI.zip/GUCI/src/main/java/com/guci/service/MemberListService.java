package com.guci.service;

import java.util.List;

import com.guci.domain.MemberListVO;

public interface MemberListService {
	public List<MemberListVO> getList();
}
