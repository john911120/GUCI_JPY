package com.guci.mapper;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.guci.domain.FaqVO;

import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class FaqMapperTests {

	//@Setter(onMethod_=@Autowired)
	@Autowired
	private FaqMapper faqMapper;

//	@Test
//	public void testInsert() {
//		FaqVO faq = new FaqVO();
//		faq.setFaqCate("교환반품");
//		faq.setFaqTit("새로 작성하는 글1");
//		faq.setFaqCon("새로 작성하는 내용1");
//
//		faqMapper.insert(faq);
//		log.info(faq);
//	}
//
//	@Test
//	public void testInsertSelectKey() {
//		FaqVO faq = new FaqVO();
//		faq.setFaqCate("상품문의");
//		faq.setFaqTit("새로 작성하는 글1 select key");
//		faq.setFaqCon("새로 작성하는 내용1 select key");
//
//		faqMapper.insertSelectKey(faq);
//		log.info(faq);
//	}

//	@Test
//	public void testRead() {
//		FaqVO faq = faqMapper.read(5L);
//		log.info(faq);
//	}

//	@Test
//	public void testDelete() {
//		log.info("DELETE COUNT : " + faqMapper.delete(2L));
//	}

	@Test
	public void testUpdate() {
		FaqVO faq = new FaqVO();
		faq.setFaqNo(5L);
		faq.setFaqCate("기타문의");
		faq.setFaqTit("수정된 제목");
		faq.setFaqCon("수정된 내용");

		int count = faqMapper.update(faq);
		log.info("UPDATE COUNT: "+count);
	}

	@Test
	public void testgetList() {
		faqMapper.getList().forEach(faq_board -> log.info(faq_board));
	}
}